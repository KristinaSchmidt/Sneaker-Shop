import { useCart } from "../../context/cartContext";
import CartCard from "../../components/cartCard";
import styles from "./styles.module.css"

export default function Cart() {
  const { cartItems, totalPrice } = useCart();
  return (
    <div className={styles.container}>
      <h2>Корзина</h2>
      <div className={styles.list}>
        {cartItems.map((item) => (
          <CartCard key={item.id} item={item} />
        ))}
      </div>

      <aside className={styles.total}>
        <h3>Итого</h3>
        {cartItems.map((i) => (
          <div key={i.id}>
            <span>{i.title}{i.qty > 1 ? ` × ${i.qty}` : ""}</span>
            <b>{i.price * i.qty} €</b>
          </div>
        ))}
        <div>
          <span>Сумма:</span> <b>{totalPrice} €</b>
        </div>
      </aside>
    </div>
  );
}