import { useCart } from "../../context/cartContext";
import styles from "./styles.module.css";

export default function CartCard({ item }) {
  const { updateQty, removeFromCart } = useCart();

  return (
    <div className={styles.card}>
      <img src={item.image} alt={item.title} className={styles.img} />

      <div className={styles.info}>
        <h4 className={styles.title}>{item.title}</h4>

        <div className={styles.row}>
          <span className={styles.price}>{item.price} €</span>

          <input
            type="number"
            min={1}
            value={item.qty}
            onChange={(e) => updateQty(item.id, Number(e.target.value))}
          />

          <button
            className={styles.remove}
            onClick={() => removeFromCart(item.id)}
            aria-label="Aus Warenkorb entfernen"
          >
            🗑
          </button>
        </div>
      </div>
    </div>
  );
}